package com.capgemini.service;


import java.util.List;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.dao.TrainDao;
import com.capgemini.dao.TrainDaoImpl;
import com.capgemini.ttb.exception.BookingException;


public class TrainServiceImpl implements TrainService {
	TrainDao dao = new TrainDaoImpl();

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		int bookTicket = dao.bookTicket(bookingBean);
		return bookTicket;
	}

	@Override
	public List<TrainBean> retrieveTrainDetails() throws BookingException {
		List<TrainBean> details = null;
		try {
			details = dao.retrieveTrainDetails();
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			throw new BookingException("Error In fetching Details");
		}
		return details;
	}
	

}
