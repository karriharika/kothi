package com.capgemini.service;


import java.util.List;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.ttb.exception.BookingException;


public interface TrainService {

	public List<TrainBean> retrieveTrainDetails() throws BookingException;
	int bookTicket(BookingBean bookingBean) throws BookingException;
}
