package com.capgemini.client;

import java.util.List;
import java.util.Scanner;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.service.TrainService;
import com.capgemini.service.TrainServiceImpl;
import com.capgemini.service.TrainValidator;
import com.capgemini.ttb.exception.BookingException;

public class MainClient {
	public static void main(String[] args){
		TrainService trainservice = new TrainServiceImpl();
		Scanner scanner = new Scanner(System.in);
		int option;
		do {
			System.out.println("1.BookTicket");
			System.out.println("2.Exit");
			System.out.println("Enter your option");

			option = scanner.nextInt();

			switch (option) {
			case 1:

				try {
					List<TrainBean> list = trainservice.retrieveTrainDetails();
					for (TrainBean tb : list) {

						System.out.println(tb);
					}
					System.out.println("1. Enter the customer id :");
					String custid = scanner.next();
					if (TrainValidator.validateCustomerId(custid) == false) {
						System.err.println("Enter valid customerid");
					}
					System.out.println("2. Enter the train id :");
					int trainid = scanner.nextInt();
					System.out.println("3. Enter the number of seats :");
					int noOfSeat = scanner.nextInt();
					BookingBean bookingBean = new BookingBean();
					bookingBean.setCustid(custid);
					bookingBean.setNoOfSeat(noOfSeat);
					bookingBean.setTrainid(trainid);
					int bookingid = trainservice.bookTicket(bookingBean);
					System.out.println("Thank you. Your booking id is " + bookingid);
				} catch (BookingException e) {
					System.err.println(e.getMessage());
				}
				break;
			case 2:
				scanner.close();
				System.exit(0);
			}
		} while (true);
	}
}
